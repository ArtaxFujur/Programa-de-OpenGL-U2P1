# 2dapgrafccartesiano
Segunda parte de la practica: Codificar una función para dibujar el plano cartesiano con sus cuatro cuadrantes. Dibuje las figuras que se muestran en el recurso y otras que se le ocurran, sea creativo.
